# Contracts — CLI, JSON, Catalog, Report

> **v1.3 (amended by WO-P3, 2026-09-11):** AXIOM-T + B3 ratio pin + exposure-retry; per WO-P1-CLOSURE. v1.2 was the v1.1 contracts with the WO-P0A amendments. v1.3 adds the three rules below.
>
> **v1.1 (amended by WO-P0A, 2026-09-11):** L1 gains the per-language `min_claims` exposure-floor param (C 600 · Rust 600 · TS 200) — resolved by the driver, passed to the runner as a scalar. Validator updated accordingly. Rationale: `claims >= 600` was an exposure-sufficiency floor calibrated on C/Rust loop speeds; TS's measured rate (211 claims vs 600 required, protocol correct, `torn=0`) showed the floor is a per-language constant, not a universal one. Floor lives in the catalog (config), never in runner code.

**Normative.** These contracts make the three runners interchangeable parts. The driver must be able to run any language's suite without knowing which language it is.

---

## 1. Runner CLI contract

```
<runner> <TEST_ID> [key=value ...]
```

- `TEST_ID` ∈ `L1-tear L2-writer-steps L3-reader-steps L4-freshness L5-progress L6-ownership L7-revocation L8-envelope`
- Values are single tokens; lists are comma-separated (`holds_ms=5,10,50`). Hex allowed with `0x` prefix.
- Runners accept **only** the params the catalog defines for that test (§3). Unknown param = hard error, exit 2.

| Test | Catalog params |
|---|---|
| L1-tear | `holds_ms` `writer_hz=240` `frames=600` `payload_max=1024` `min_claims` *(per-language map in catalog; driver resolves → scalar)* |
| L2-writer-steps | `holds_ms` `publishes=2000` `writer_hz=2000` `payload_max=256` `bound=2` |
| L3-reader-steps | `writer_hz=960` `claims=2000` `payload_max=256` `bound=2` |
| L4-freshness | `writer_hz=960` `reader_hz=240` `frames=2000` `payload_max=256` |
| L5-progress | `holds_ms` `window_s=1.0` `writer_hz=2000` `payload_max=256` `tolerance=1.5` |
| L6-ownership | `trials=200` `frames=64` `max_delay_us=500` `payload_max=256` `seed=0x00C0FFEE` |
| L7-revocation | `timeout_ms=2000` `payload_max=256` |
| L8-envelope | *(none)* |

**Binaries:** `core/c/spike` · `core/rust/target/release/litmus` · `node core/ts/litmus.ts <args>` (TS runs via Node type-stripping — verified, see 06 §1).

## 2. Verdict output contract

- **stdout:** exactly ONE line, the JSON object below, as the LAST line. All human/diagnostic output → **stderr**.
- **exit:** 0 pass · 1 fail · 2 usage/contract error.

```json
{"test":"L1-tear","lang":"c","pass":true,"metrics":{"holds_ms":[5,10,50],"claims":1803,"torn":0,"drain_ok":true},"notes":"optional, ≤200 chars"}
```

- `lang` ∈ `c | rust | ts` — hardcoded per runner.
- `metrics` keys are **exactly** those specified in 04-LITMUS per test (driver validation is schema-lite: presence + numeric/bool type).
- No NaN/Infinity; rates rounded to 1 decimal.

## 3. `litmus/catalog.yaml` — the canonical artifact

The catalog is the machine-readable specification of the suite. It carries: metadata, the **memory-ordering matrix** (copied verbatim from 02 §5 — the three kernels must cite it, not restate it), and the eight test definitions (params from §1 above, plus `adversary` and `verdict` strings quoted from 04-LITMUS).

Schema (enforced by `tools/validate_catalog.py`):

```yaml
catalog: weft-litmus
version: 1
defaults: { payload_max: 256, seed: 0x00C0FFEE }
ordering_matrix:            # REQUIRED — keys exactly as 02 §5
  latest:    { op: exchange_writer_and_reader, ordering: acq_rel, note: single RMW ownership transfer }
  revoked:   { writer_load: relaxed, releaser_store: release, note: advisory check, correctness via ACK }
  epoch:     { writer_ack: fetch_add_acqrel, reclaim_poll: acquire, note: licenses poison/free }
  telemetry: { op: fetch_add, ordering: relaxed, note: never synchronization }
  t_publish_reads: { op: load, ordering: acquire, note: L4 freshness protocol }
tests:
  - id: L1-tear
    adversary: "reader hold 5/10/50 ms; writer 2x display rate"
    verdict: "torn == 0 across all holds AND drain_ok AND claims >= min_claims"
    params: { holds_ms: [5, 10, 50], writer_hz: 240, frames: 600, payload_max: 1024,
              min_claims: { c: 600, rust: 600, ts: 200 } }   # exposure floor, per-language, catalog-owned
  # ... L2–L8, same shape, params per §1
```

Validator checks: all 8 IDs present and ordered · every param in §1 present (defaults allowed) · `ordering_matrix` keys exact · verdict/adversary strings non-empty · no unknown top-level keys · `min_claims`, when present, is a map with exactly the keys `c`, `rust`, `ts` and positive integer values. **The driver refuses to run against an invalid catalog.**

**Driver resolution rule (v1.1):** for a per-language map param, the driver selects the current language's value and passes it on the CLI as a scalar (`min_claims=200`). Runners therefore only ever see scalars and stay language-blind.

## 4. Driver — `tools/litmus_driver.py`

Responsibilities (it builds nothing; build via `make` first):

1. Load + validate the catalog.
2. For each language in `--langs c,rust,ts` (default all) and each test: invoke the runner per §1, timeout **120 s** wall, capture stdout JSON + stderr.
3. Assemble the matrix; enforce A6: any cell red while its cross-language counterparts are green → flag `CROSS-LANGUAGE-DIVERGENCE` in the report.
4. Write `litmus/REPORT.md` (§5) and a machine bundle `litmus/results.json` (raw verdicts + env).
5. Exit non-zero if any cell is red.

Run matrix: 8 tests × 3 languages = **24 cells**, executed twice (debug + release C/Rust; TS is single-mode, counted once) → 40 runner invocations expected in ~3–4 min total.

## 5. `litmus/REPORT.md` — generated, never hand-edited

```markdown
# Weft Phase 0 — Litmus Report (auto-generated by litmus_driver.py v1)
Run: <UTC timestamp> · Catalog: weft-litmus v1 · Honesty label: x86_64-sandbox (runtime-verified)

## Matrix
| Test | C (debug) | C (release) | Rust (debug) | Rust (release) | TS | 
|---|---|---|---|---|---|
| L1-tear | ✅ torn=0 | ✅ | ✅ | ✅ | ✅ |     ← one row per test, cell shows key metric
... 8 rows, 24 cells

## Environment (captured at run time)
uname · gcc --version · rustc --version · node --version · python3 --version · CPU model/cores

## Cross-language consistency
Statement per A6 + any divergence notes with seeds/params for replay.

## Evidence
results.json path · per-cell stdout/stderr excerpts on any red.
```

Rules: every number carries the `x86_64-sandbox` label at least once at the top · a missing language is a **red row with reason**, not an omission · the report includes the catalog's verdict strings so it reads standalone.

## 6. Makefile contract (repo root)

```
make build-c      # gcc -O2 -std=c11 -Wall -Wextra -pthread core/c/{weft.c,litmus_runner.c} -o core/c/spike
make build-c-dbg  # -O0 -g -fsanitize=thread  (output core/c/spike-tsan — A8 column)
make build-rust   # cargo build --release --offline (also: cargo build for debug)
make litmus       # build-c build-rust, then python3 tools/litmus_driver.py
make tsan         # driver --runner core/c/spike-tsan --langs c (A8 supplementary column)
make clean
```

`--offline` is mandatory on cargo (no network dependency at build time; the kernel has zero crates).

---

## AXIOM T — Telemetry is not a correctness reference

Telemetry counters (claims_per_s, publish counters, max_published, and any future counter)
are advisory. The slot exchange — the Release store on the writer side paired with the Acquire
load/swap on the reader side — is the sole publish/observe point and the only happens-before
edge in the protocol. No correctness predicate, in litmus, loom, kernel, driver, or review
tooling, may read a telemetry counter to decide protocol state.

Rationale: Phase 0 F1 and the loom v1 false-RED are the same defect class — a lagging
telemetry store mistaken for the publish point. Telemetry lags the exchange by construction.
(Post-join reads of telemetry for reporting are fine; in-flight reads are not.)

### B3 ratio definition (pinned)

ratio := p50(64K) / p50(64B). Both p50s are always reported alongside the ratio.
A ratio < 1.0 is legal for a swap primitive (cache/alignment effects may favor either size);
REPORT.md must carry a one-line note whenever ratio < 1.0 or run-to-run ratio delta > 0.3.
Gate remains: ratio < 2.0 (structural, zero-copy proof). [WO-P1-CLOSURE §5]

### Exposure retry (L1)

Driver retries an L1 cell exactly once when claims < min_claims, labeled EXPOSURE-RETRY in
the report. An exposure shortfall after retry is reported as an exposure finding — it is
never auto-converted to green. [WO-P1-CLOSURE §6]
